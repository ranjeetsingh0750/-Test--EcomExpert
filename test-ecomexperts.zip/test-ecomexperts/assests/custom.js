
$(document).ready(function() {
  $(".thumbnail-list__item button").hover(function() {
   //debugger
    jQuery(this).trigger( "click" );
  
});
  
    $(".remove-btn").click(function() {
   //debugger
    var current = jQuery(this).data('variant');
    var another = jQuery('.remove-btn').data('variant');
      if(current == 44243867762981 ){
        if(another = 44240864543013){
          jQuery('.remove-btn').click();
           location.reload(true);
        }
      }
  });
});
